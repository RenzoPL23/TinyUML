package org.tinyuml.ui.diagram.commands;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javax.swing.undo.AbstractUndoableEdit;
import org.tinyuml.draw.CompositeNode;
import org.tinyuml.draw.Connection;
import org.tinyuml.draw.DiagramElement;
import org.tinyuml.draw.Node;
import org.tinyuml.util.Command;

public class CopyElementCommand extends AbstractUndoableEdit
implements  Command{

    private Collection<DiagramElement> elements;
    private DiagramEditorNotification notification;

    private static class ParentChildRelation {
        DiagramElement element;
        CompositeNode parent;

        /**
         * Constructor.
         * @param anElement the element
         * @param aParent the element's parent
         */
        public ParentChildRelation(DiagramElement anElement,
                                   CompositeNode aParent)  {
            parent = aParent;
            element = anElement;
        }
    }
    private List<ParentChildRelation> parentChildRelations = new ArrayList<ParentChildRelation>();
    public CopyElementCommand(DiagramEditorNotification aNotification,
                              Collection<DiagramElement> theElement){
        notification = aNotification;
        elements = theElement;
        for (DiagramElement elem: elements){
            parentChildRelations.add(new ParentChildRelation(elem,elem.getParent()));
        }
    }
    public void run(){
        for( DiagramElement element: elements){
            if (element instanceof Connection) {
                reattachConnectionToNodes((Connection) element);
            } else if (element instanceof Node) {
                reattachNodeConnections((Node) element);
            }
            element.getParent().addChild(element);
            notification.notifyElementAdded(element);
        }
    }
    @Override
    public void redo() {
        super.redo();
        run();
    }
    @Override
    public void undo() {
        super.undo();
        for (ParentChildRelation relation : parentChildRelations) {
            if (relation.element instanceof Connection) {
                reattachConnectionToNodes((Connection) relation.element);
            } else if (relation.element instanceof Node) {
                reattachNodeConnections((Node) relation.element);
            }
            relation.parent.addChild(relation.element);
            notification.notifyElementAdded(relation.element);
        }
    }
    private void detachNodeConnections(Node node) {
        for (Connection conn : node.getConnections()) {
            if (conn.getNode1() != node) conn.getNode1().removeConnection(conn);
            if (conn.getNode2() != node) conn.getNode2().removeConnection(conn);
            conn.getParent().removeChild(conn);
        }
    }
    private void reattachNodeConnections(Node node) {
        for (Connection conn : node.getConnections()) {
            if (conn.getNode1() != node) conn.getNode1().addConnection(conn);
            if (conn.getNode2() != node) conn.getNode2().addConnection(conn);
            conn.getParent().addChild(conn);
        }
    }
    private void detachConnectionFromNodes(Connection conn) {
        conn.getNode1().removeConnection(conn);
        conn.getNode2().removeConnection(conn);

    }
    private void reattachConnectionToNodes(Connection conn) {
        conn.getNode1().addConnection(conn);
        conn.getNode2().addConnection(conn);
    }
}
